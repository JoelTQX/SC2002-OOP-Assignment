package entities;

public class Administrator extends Staff{

	public Administrator(String userID, String userPass, boolean firstLogin, String userRole) {
		super(userID, userPass, firstLogin, userRole);
	}

}
