package controllers;

public class AdministratorController {

}
