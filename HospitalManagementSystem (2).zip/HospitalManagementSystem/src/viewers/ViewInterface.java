package viewers;

public interface ViewInterface {
	public boolean displayMenu();
}
