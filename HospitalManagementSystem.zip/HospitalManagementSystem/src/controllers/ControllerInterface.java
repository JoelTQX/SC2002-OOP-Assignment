package controllers;

public interface ControllerInterface {
	public String getUserID();
}
