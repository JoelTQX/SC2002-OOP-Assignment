package entities;

public class Appointment {
}
