package entities;

public class AppointmentOutcome {

}
