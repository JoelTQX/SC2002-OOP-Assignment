package entities;

public class Patient extends User{
	public Patient(String userID, String userPass, boolean firstLogin) {
		super(userID, userPass, firstLogin);
	}
}
