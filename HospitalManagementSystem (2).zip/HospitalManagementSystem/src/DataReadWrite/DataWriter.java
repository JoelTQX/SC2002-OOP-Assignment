package DataReadWrite;

import java.io.IOException;

public interface DataWriter {
	public void write(int x, int y,String message) throws IOException;
}
