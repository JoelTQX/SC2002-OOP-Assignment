package DataReadWrite;

import java.io.IOException;

public interface DataPrinter {
	
	public void print() throws IOException;

}
