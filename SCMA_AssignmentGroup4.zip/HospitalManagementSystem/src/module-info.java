/**
 * 
 */
/**
 * 
 */
module HospitalManagementSystem {
}