package entities;

public class Pharmacist extends Staff{

	public Pharmacist(String userID, String userPass, boolean firstLogin, String userRole) {
		super(userID, userPass, firstLogin, userRole);
	}

}
